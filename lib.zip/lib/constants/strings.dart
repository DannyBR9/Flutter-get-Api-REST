
class Strings {
  static final String apiKey = "b5493bab347945538d60d0f71e7c3880";
  static String newUrl = 'http://jsonplaceholder.typicode.com/posts';
}
